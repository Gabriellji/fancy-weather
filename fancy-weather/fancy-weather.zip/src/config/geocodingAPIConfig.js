const geocodingApiConfig = {
	geocodingUrl: 'https://api.opencagedata.com/geocode/v1/json',
	accesKey: 'e4a2d4b3cfe041ddacf65d548c8cd504',
};

export default geocodingApiConfig;
