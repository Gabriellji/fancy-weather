const backgroundApiConfig = {
	url: 'https://api.unsplash.com/photos/random',
	accesKey: 'pu6drrWomvHIiuHpdXsBe9_iFMeRVpZSxQiJZUrAdGg',
	collectionsID: '2411320',
	orientation: 'landscape',
};

export default backgroundApiConfig;
