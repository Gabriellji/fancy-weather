const backgroundApiConfig = {
	url: 'https://api.unsplash.com/photos/random',
	accesKey: 'cP-0wng17U5SFKixYetdbAYEofMl6GlWC9POsTXhI2Q', //   pu6drrWomvHIiuHpdXsBe9_iFMeRVpZSxQiJZUrAdGg
	collectionsID: '2411320',
	orientation: 'landscape',
};

export default backgroundApiConfig;
