const weatherApiConfig = {
	url: 'https://api.weatherapi.com/v1/forecast.json',
	accesKey: '86f6485ca8ca41d1b0c163610201905',
};

export default weatherApiConfig;
