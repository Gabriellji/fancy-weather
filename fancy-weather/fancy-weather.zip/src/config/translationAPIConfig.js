const translationApiConfig = {
	url: 'https://translate.yandex.net/api/v1.5/tr.json/translate',
	accesKey: 'trnsl.1.1.20200507T094434Z.cb218a7a76e13e79.42f8386df67cf8d4a33ebab1bd2bcfe79d3890fa',
};

export default translationApiConfig;
