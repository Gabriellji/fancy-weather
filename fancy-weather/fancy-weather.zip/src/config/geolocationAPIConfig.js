const geolocationApiConfig = {
	geolocationUrl: 'https://ipinfo.io',
	accesKey: '67e2f4de942b0a',
};

export default geolocationApiConfig;
