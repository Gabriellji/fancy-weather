const weekdays = [
	'Нядзеля', 'Панядзелак', 'Аўторак', 'Серада', 'Чацьвер', 'Пятніца', 'Субота',
];

export default weekdays;
