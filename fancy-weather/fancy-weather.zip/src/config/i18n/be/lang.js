const lang = {
	main: {
		title: '',
		description: '',
	},
	control: {
		searchPlaceholder: 'Знайсці горад ці індэкс',
		searchBtnTxt: 'Пошук',
	},
	weatherToday: {
		feelsLike: 'Адчуваецца як:',
		wind: 'Хуткасць ветру::',
		humidity: 'Вiльготнасць:',
	},
	map: {
		latitude: 'Шырата:',
		longitude: 'Даўгата: ',
	},
};
