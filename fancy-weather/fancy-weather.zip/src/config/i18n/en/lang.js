const lang = {
	main: {
		title: '',
		description: '',
	},
	control: {
		searchPlaceholder: 'Search city or ZIP',
		searchBtnTxt: 'Search',
	},
	weatherToday: {
		feelsLike: 'Feels like:',
		wind: 'Wind:',
		humidity: 'Humidity:',
	},
	map: {
		latitude: 'Latitude:',
		longitude: 'Longitude:',
	},
};
