const lang = {
	main: {
		title: '',
		description: '',
	},
	control: {
		searchPlaceholder: 'Найти город или индекс',
		searchBtnTxt: 'ПОИСК',
	},
	weatherToday: {
		feelsLike: 'ОЩУЩАЕТСЯ КАК:',
		wind: 'ВЕТЕР:',
		humidity: 'ВЛАЖНОСТЬ:',
	},
	map: {
		latitude: 'Широта:',
		longitude: 'Долгота:',
	},
};
