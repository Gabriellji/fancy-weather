const mapApiConfig = {
	mapUrl: 'https://api.mapbox.com',
	accesKey: 'pk.eyJ1IjoiZ2FicmllbGppIiwiYSI6ImNrYWlia2RzZzBnbGUycnRpa3hxcmoyMWsifQ.XWfWA24Tsh69PdXI3XQjlg',
};

export default mapApiConfig;
