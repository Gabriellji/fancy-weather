
import i18n from './I18n';

const Model = {
	i18n,

};

export default model;
