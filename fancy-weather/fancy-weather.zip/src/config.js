export default {
	unsplashUrl: 'https://api.unsplash.com/',
	unsplashKey: 'pu6drrWomvHIiuHpdXsBe9_iFMeRVpZSxQiJZUrAdGg',
};
